<?php

$GLOBALS[$GLOBALS['idx_lang']] = array(

'icone_brouteur' => 'Sommaire',

);


?>